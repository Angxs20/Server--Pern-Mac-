export function sumar(num1:number, num2:number){
   
    console.log(num1+num2);
    
}